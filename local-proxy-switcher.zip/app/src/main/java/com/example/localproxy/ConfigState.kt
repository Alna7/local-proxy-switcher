
package com.example.localproxy

object ConfigState {
    const val CONFIG_1 = "CONFIG_1"
    const val CONFIG_2 = "CONFIG_2"

    @Volatile
    var activeConfig: String = CONFIG_1

    @Volatile
    var switched: Boolean = false
}
