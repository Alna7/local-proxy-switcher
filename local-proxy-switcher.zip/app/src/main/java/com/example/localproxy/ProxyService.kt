
package com.example.localproxy

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlin.concurrent.thread

class ProxyService : Service() {

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val CHANNEL_ID = "proxy_service_channel"
        const val NOTIFICATION_ID = 1001
    }

    @Volatile
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startProxy()
            ACTION_STOP -> stopProxy()
        }
        return START_STICKY
    }

    private fun startProxy() {
        if (running) return

        startForeground(NOTIFICATION_ID, buildNotification("Proxy running on 127.0.0.1:2080"))
        running = true

        TrafficCounter.reset()
        ConfigState.activeConfig = ConfigState.CONFIG_1
        ConfigState.switched = false

        thread(start = true) {
            while (running) {
                Thread.sleep(1000)

                val reached = TrafficCounter.addBytes(120 * 1024)

                if (reached && !ConfigState.switched) {
                    ConfigState.activeConfig = ConfigState.CONFIG_2
                    ConfigState.switched = true

                    val nm = getSystemService(NotificationManager::class.java)
                    nm.notify(
                        NOTIFICATION_ID,
                        buildNotification("Switched to CONFIG_2 on 127.0.0.1:2080")
                    )
                }
            }
        }
    }

    private fun stopProxy() {
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Local Proxy Switcher")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setOngoing(true)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Proxy Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
