
package com.example.localproxy

object TrafficCounter {
    private const val THRESHOLD_BYTES = 1024 * 1024L

    @Volatile
    var totalBytes: Long = 0L

    fun addBytes(count: Int): Boolean {
        if (count > 0) {
            totalBytes += count.toLong()
        }
        return totalBytes >= THRESHOLD_BYTES
    }

    fun reset() {
        totalBytes = 0L
    }
}
